const fototitulo = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/EXERCICIO1PARTE2/img/pexels-l%C3%BAcio-arantes-3656636.jpg";
const foto1 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/IMG_20230216_205400_2.jpg";
const foto2 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/meadow-3628843__340.jpg";
const foto3 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/living-room-2732939__340%20(1).jpg";
const foto4 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/living-room-2569325__340.jpg";
const foto5 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/bedroom-1872196__340%20(1).jpg";
const foto6 = "https://raw.githubusercontent.com/marcionoronha1995/futurodev2023/main/Exercicio1parte2/img/blooming-field-5304878__340.jpg";

document.getElementById('imagem1').src=foto1;
document.getElementById('imagem2').src=foto2;
document.getElementById('imagem3').src=foto3;
document.getElementById('imagem4').src=foto4;
document.getElementById('imagem-autor').src=foto1;
document.getElementById('imagem1-modal').src=foto1;
document.getElementById('imagem2-modal').src=foto2;
document.getElementById('imagem3-modal').src=foto3;
document.getElementById('imagem4-modal').src=foto4;


